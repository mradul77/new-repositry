from flask import jsonify, request
from user_app.services.user_service import UserService

user_service = UserService()

def get_users():
    return jsonify(user_service.get_all_users())

def add_user():
    data = request.get_json()
    user_service.add_user(data)
    return jsonify({"message": "User added successfully"}), 201
