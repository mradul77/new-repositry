from user_app.models.user_model import User
from shared.models.db import db

class UserService:
    def get_all_users(self):
        return [user.to_dict() for user in User.query.all()]

    def add_user(self, data):
        new_user = User(**data)
        db.session.add(new_user)
        db.session.commit()
