from flask import Blueprint
from user_app.controllers.user_controller import get_users, add_user

user_bp = Blueprint('users', __name__)

user_bp.route('/', methods=['GET'])(get_users)
user_bp.route('/', methods=['POST'])(add_user)
