from flask import Blueprint
from book_app.controllers.book_controller import get_books, add_book

book_bp = Blueprint('books', __name__)

book_bp.route('/', methods=['GET'])(get_books)
book_bp.route('/', methods=['POST'])(add_book)
