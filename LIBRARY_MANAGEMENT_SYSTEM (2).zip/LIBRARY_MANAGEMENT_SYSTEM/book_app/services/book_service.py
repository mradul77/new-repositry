from book_app.models.book_model import Book
from shared.models.db import db

class BookService:
    def get_all_books(self):
        return [book.to_dict() for book in Book.query.all()]

    def add_book(self, data):
        new_book = Book(**data)
        db.session.add(new_book)
        db.session.commit()
