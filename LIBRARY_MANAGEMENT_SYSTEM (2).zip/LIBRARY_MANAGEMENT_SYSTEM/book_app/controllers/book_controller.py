from flask import jsonify, request
from book_app.services.book_service import BookService

book_service = BookService()

def get_books():
    return jsonify(book_service.get_all_books())

def add_book():
    data = request.get_json()
    book_service.add_book(data)
    return jsonify({"message": "Book added successfully"}), 201
