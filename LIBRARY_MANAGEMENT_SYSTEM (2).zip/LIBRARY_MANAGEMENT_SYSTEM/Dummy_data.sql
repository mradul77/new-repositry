CREATE DATABASE library_management_app;
USE library_management_app;

CREATE TABLE users(
    id INT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO users (id, name, email) VALUES
(1, 'Rajesh Kumar', 'rajesh.kumar@example.com'),
(2, 'Priya Sharma', 'priya.sharma@example.com'),
(3, 'Anil Mehta', 'anil.mehta@example.com'),
(4, 'Deepika Joshi', 'deepika.joshi@example.com'),
(5, 'Vikram Patel', 'vikram.patel@example.com');

CREATE TABLE books(
    id INT PRIMARY KEY,
    title VARCHAR(50) NOT NULL,
    author VARCHAR(50) NOT NULL,
    published_date DATETIME
);

INSERT INTO books (id, title, author, published_date) VALUES
(1, 'The Banyan Tree', 'R. K. Narayan', '1980-06-15 10:00:00'),
(2, 'Wings of Fire', 'A. P. J. Abdul Kalam', '1999-01-01 09:30:00'),
(3, 'Train to Pakistan', 'Khushwant Singh', '1956-07-01 12:00:00'),
(4, 'God of Small Things', 'Arundhati Roy', '1997-05-15 11:00:00'),
(5, 'Malgudi Days', 'R. K. Narayan', '1943-01-01 08:00:00');

